#!/bin/sh


javac -d compilation/ -cp ~/Téléchargements/jbotsim-standalone-1.0.0.jar:  src/**/*.java

for i in `seq 0 1000`:
	do 
	echo iteration = $i
	java  -cp compilation/:jbotsim-standalo-1.0.0.jar:. lancement_simulation.Simulation_for_script
	done
