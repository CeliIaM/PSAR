package lancement_simulation;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

import classes_graphes.AC;
import classes_graphes.BRE;
import classes_graphes.COT;
import classes_graphes.Graphe;
import classes_graphes.Noeud;
import classes_graphes.RE;
import classes_graphes.ST;
import io.jbotsim.core.Topology;
import io.jbotsim.ui.JViewer;
import robots.Robot;
import robots.Robot_gestionnaire;

public class Simulation_for_script {

	public static void main(String[] args) {

		// *********************************************************************************************************
		// HAVE TO BE COMPLETED BY THE USERS

		String type_graphe = "COT"; // Type of graph
		int nb_noeud = 10; // Number of nodes
		int nb_robot = 4; // Number of robots
		int proba_disparition_simple = 20; // probability of disappearance of edges
		int proba_disparition_missing = 5; // probability to have an eventual missing edge
		int temps_tirage_missing_egde = 9; // Time when we try to pull the missing edge
		int temps_max = 10; // Terminal time fixed for the reappearance (only initial for COT, AC and RE)
		boolean can_finish = false; // Gathering possible ?
		 /* Time when after the weak gathering the simulation stops if can_finish is
		  * false
		  */
		int timeout = 50;
	
	
	

		// *********************************************************************************************************

		// Creation of the graph depending of type_graphe
		Graphe graph = null;
		switch (type_graphe) {
		case "ST":
			graph = new ST(nb_noeud);
			break;
		case "BRE":
			graph = new BRE(nb_noeud, proba_disparition_simple, temps_max);
			break;
		case "RE":
			graph = new RE(nb_noeud, proba_disparition_simple, temps_max);
			break;
		case "AC":
			graph = new AC(nb_noeud, proba_disparition_simple, temps_max, proba_disparition_missing,
					temps_tirage_missing_egde);
			break;
		case "COT":
			graph = new COT(nb_noeud, proba_disparition_simple, proba_disparition_missing, temps_tirage_missing_egde,
					temps_max);
			break;

		}

		// Initialization of the Topology
		Topology tp = new Topology();
		tp.setSensingRange(1);

		// Display the graph
		graph.afficher(tp);

		// Robot managing the graph
		Robot_gestionnaire robot = new Robot_gestionnaire(graph, tp);
		tp.addNode(robot);

		// Counter of robots
		int cpt_robot = nb_robot;

		/*
		 * These two lists are browsed simultaneously.
		 */
		ArrayList<Integer> id_robots = new ArrayList<>();
		ArrayList<Noeud> localisation_robot = new ArrayList<>();

		/*
		 * As we need the total number of robots we can not insert them on the go in the
		 * topology so we save their identifier and their future position to create them
		 * later
		 */
		while (cpt_robot > 0) {
			for (Noeud n : graph.getNoeuds()) {
				if (Math.random() * 100 < 50 && cpt_robot > 0) {
					int identifiant = (int) (Math.random() * 100);
					while (id_robots.contains(identifiant) || identifiant == 0) {
						identifiant = (int) (Math.random() * 100);
					}
					id_robots.add(identifiant);
					localisation_robot.add(n);
					System.out.println("id " + identifiant + " Localisation " + n.getLocation());
					cpt_robot--;

				}

			}
		}

		// We can now create them and insert them into the Topology
		for (int i = 0; i < id_robots.size(); i++) {
			Noeud position = localisation_robot.get(i);
			tp.addNode(position.getLocation().getX(), position.getLocation().getY(), new Robot(type_graphe,
					id_robots.get(i), position, nb_robot, nb_noeud, timeout, can_finish, robot, tp));
		}

		/*
		 * We write in a file: - the value of the reappearance terminal (used only for
		 * BRE) - the number of nodes of the graph - the number of robots as well as
		 * their id
		 */
		File file = new File("Resultats_" + type_graphe);
		if (!file.exists()) {
			try {
				file.createNewFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		try {
			DataOutputStream out = new DataOutputStream(new FileOutputStream(file, true));
			out.writeBytes("Borne " + temps_max + "\n");
			out.writeBytes("Noeuds " + nb_noeud + "\n");
			out.writeBytes("Robots " + id_robots.size() + "\n");
			for (int i = 0; i < id_robots.size(); i++) {
				out.writeBytes("" + id_robots.get(i) + "\n");
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		tp.start();
	}

}
