package lancement_simulation;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Font;
import java.awt.Label;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JSlider;
import javax.swing.ListCellRenderer;
import javax.swing.border.TitledBorder;

import classes_graphes.AC;
import classes_graphes.BRE;
import classes_graphes.COT;
import classes_graphes.Graphe;
import classes_graphes.Noeud;
import classes_graphes.RE;
import classes_graphes.ST;
import io.jbotsim.core.Topology;
import io.jbotsim.ui.JTopology;
import io.jbotsim.ui.JViewer;
import robots.Robot;
import robots.Robot_gestionnaire;

public class Simulation_graphique implements ActionListener {
	private Topology tp;
	private JSlider probabilite;
	private JSlider probabilite_missing_edge;
	private JCheckBox can_finish_check;
	private JSlider nb_noeud;
	private JComboBox<String> choix_classe;
	private JFormattedTextField borne;
	private JFormattedTextField nb_robots;
	private JFormattedTextField temps_missing_edge;

	private Graphe graphe;
	private int nb_noeuds;
	private int proba_disparition;
	private int val_borne;
	private int proba_missing;
	private int temps_missing_ed;
	private String type_graphe;
	boolean can_finish = false;;

	public Simulation_graphique() {
		tp = new Topology();
		JFrame window = new JFrame("Rassemblement_Robots");
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setLayout(new BorderLayout());

		Container conteneur = window.getContentPane();
		Box vbox = Box.createVerticalBox();

		nb_robots = new JFormattedTextField(NumberFormat.getIntegerInstance());
		nb_robots.setBorder(BorderFactory.createTitledBorder("Nombre de robots"));

		borne = new JFormattedTextField(NumberFormat.getIntegerInstance());
		borne.setBorder(BorderFactory.createTitledBorder("Borne réapparition"));

		temps_missing_edge = new JFormattedTextField(NumberFormat.getIntegerInstance());
		temps_missing_edge.setBorder(BorderFactory.createTitledBorder("Date tirage missing edge"));

		probabilite = new JSlider(0, 100, 0);
		probabilite.setPaintTicks(true);
		probabilite.setPaintLabels(true);
		probabilite.setMajorTickSpacing(10);
		probabilite.setMinorTickSpacing(5);
		probabilite.setBorder(BorderFactory.createTitledBorder("Probabilité disparition arête"));

		probabilite_missing_edge = new JSlider(0, 100, 0);
		probabilite_missing_edge.setPaintTicks(true);
		probabilite_missing_edge.setPaintLabels(true);
		probabilite_missing_edge.setMajorTickSpacing(10);
		probabilite_missing_edge.setMinorTickSpacing(5);
		probabilite_missing_edge.setBorder(BorderFactory.createTitledBorder("Probabilité arête ultimement manquante"));

		nb_noeud = new JSlider(0, 12, 0);
		nb_noeud.setPaintTicks(true);
		nb_noeud.setPaintLabels(true);
		nb_noeud.setMajorTickSpacing(1);
		nb_noeud.setBorder(BorderFactory.createTitledBorder("Choix du nombre de noeuds"));

		String[] l = { "ST", "BRE", "AC", "RE", "COT" };
		choix_classe = new JComboBox<String>(l);
		choix_classe.setActionCommand("Graphe");
		choix_classe.addActionListener(this);

		can_finish_check = new JCheckBox("Gathering possible ?");
		can_finish_check.addActionListener(this);

		JButton button = new JButton(new ImageIcon("bouton.png"));
		button.setText("");
		button.addActionListener(this);

		ListCellRenderer lcr = new ListCellRenderer() {
			public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected,
					boolean cellHasFocus) {
				JLabel l = new JLabel();
				l.setText(value.toString());
				l.setForeground(isSelected ? Color.white : Color.red);
				return l;
			}
		};
		conteneur.setBackground(Color.DARK_GRAY);

		can_finish_check.setBackground(Color.DARK_GRAY);
		can_finish_check.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		can_finish_check.setForeground(Color.white);
		can_finish_check.setAlignmentX(Label.CENTER_ALIGNMENT);

		button.setBackground(Color.DARK_GRAY);
		button.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		button.setForeground(Color.white);
		button.setAlignmentX(Label.CENTER_ALIGNMENT);

		choix_classe.setBackground(Color.DARK_GRAY);
		choix_classe.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		choix_classe.setForeground(Color.white);
		choix_classe.setAlignmentX(Label.CENTER_ALIGNMENT);
		choix_classe.setBorder(BorderFactory.createLineBorder(Color.RED));
		choix_classe.setRenderer(lcr);

		probabilite.setBackground(Color.DARK_GRAY);
		probabilite.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		probabilite.setForeground(Color.red);
		TitledBorder border = BorderFactory.createTitledBorder("Probabilité disparition arête");
		border.setTitleColor(Color.white);
		border.setBorder(BorderFactory.createLineBorder(Color.red));
		probabilite.setBorder(border);

		probabilite_missing_edge.setBackground(Color.DARK_GRAY);
		probabilite_missing_edge.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		probabilite_missing_edge.setForeground(Color.red);
		TitledBorder border2 = BorderFactory.createTitledBorder("Probabilité arête ultimement manquante");
		border2.setTitleColor(Color.white);
		border2.setBorder(BorderFactory.createLineBorder(Color.red));
		probabilite_missing_edge.setBorder(border2);

		temps_missing_edge.setBackground(Color.DARK_GRAY);
		temps_missing_edge.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		temps_missing_edge.setForeground(Color.white);
		temps_missing_edge.setAlignmentX(Label.CENTER_ALIGNMENT);
		temps_missing_edge.setBorder(BorderFactory.createLineBorder(Color.RED));
		TitledBorder border1 = BorderFactory.createTitledBorder("Date tirage missing edge");
		border1.setTitleColor(Color.white);
		border1.setBorder(BorderFactory.createLineBorder(Color.red));
		temps_missing_edge.setBorder(border1);

		nb_noeud.setBackground(Color.DARK_GRAY);
		nb_noeud.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		nb_noeud.setForeground(Color.red);
		TitledBorder border3 = BorderFactory.createTitledBorder("Choix du nombre de noeuds");
		border3.setTitleColor(Color.white);
		border3.setBorder(BorderFactory.createLineBorder(Color.red));
		nb_noeud.setBorder(border3);

		borne.setBackground(Color.DARK_GRAY);
		borne.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		borne.setForeground(Color.white);
		borne.setAlignmentX(Label.CENTER_ALIGNMENT);
		borne.setBorder(BorderFactory.createLineBorder(Color.RED));
		TitledBorder border4 = BorderFactory.createTitledBorder("Borne réapparition");
		border4.setTitleColor(Color.white);
		border4.setBorder(BorderFactory.createLineBorder(Color.red));
		borne.setBorder(border4);

		nb_robots.setBackground(Color.DARK_GRAY);
		nb_robots.setFont(new Font(Font.DIALOG, Font.BOLD, 15));
		nb_robots.setForeground(Color.white);
		nb_robots.setAlignmentX(Label.CENTER_ALIGNMENT);
		nb_robots.setBorder(BorderFactory.createLineBorder(Color.RED));
		TitledBorder border5 = BorderFactory.createTitledBorder("Nombre de robots : minimum 4");
		border5.setTitleColor(Color.white);
		border5.setBorder(BorderFactory.createLineBorder(Color.red));
		nb_robots.setBorder(border5);

		vbox.add(nb_noeud);
		vbox.add(nb_robots);
		vbox.add(probabilite);
		vbox.add(probabilite_missing_edge);
		vbox.add(temps_missing_edge);
		vbox.add(borne);
		vbox.add(can_finish_check);
		vbox.add(choix_classe);

		vbox.add(button);
		conteneur.add(vbox, BorderLayout.EAST);
		window.add(new JTopology(tp));
		window.pack();
		window.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Graphe")) {
			nb_noeuds = nb_noeud.getValue();

			type_graphe = (String) choix_classe.getSelectedItem();
			switch (type_graphe) {
			case "ST":
				System.out.println("Nombre noeud " + nb_noeuds);
				graphe = new ST(nb_noeuds);
				break;
			case "BRE":
				proba_disparition = probabilite.getValue();
				val_borne = Integer.parseInt(borne.getText());
				graphe = new BRE(nb_noeuds, proba_disparition, val_borne);
				break;
			case "AC":
				val_borne = Integer.parseInt(borne.getText());
				proba_disparition = probabilite.getValue();
				proba_missing = probabilite_missing_edge.getValue();
				temps_missing_ed = Integer.parseInt(temps_missing_edge.getText());
				graphe = new AC(nb_noeuds, proba_disparition, val_borne,proba_missing,temps_missing_ed);
				break;
			case "RE":
				proba_disparition = probabilite.getValue();
				val_borne = Integer.parseInt(borne.getText());
				graphe = new RE(nb_noeuds, proba_disparition, val_borne);
				break;
			case "COT":
				val_borne = Integer.parseInt(borne.getText());
				proba_disparition = probabilite.getValue();
				proba_missing = probabilite_missing_edge.getValue();
				temps_missing_ed = Integer.parseInt(temps_missing_edge.getText());
				graphe = new COT(nb_noeuds, proba_disparition, proba_missing, temps_missing_ed, val_borne);
				break;
			}
		}
		if (e.getActionCommand().equals("Gathering possible ?")) {
			can_finish = true;

		}
		if (e.getActionCommand().equals("")) {

			tp.setSensingRange(1);
			graphe.afficher(tp);
			int nb_robot = Integer.parseInt(nb_robots.getText());
			int cpt_robot = nb_robot;
			int timeout = Integer.parseInt(borne.getText());
			Robot_gestionnaire robot = new Robot_gestionnaire(graphe, tp);
			tp.addNode(robot);

			/*
			 * Ces deux listes sont parcourrues en simultané . Un identifiant est associé à
			 * une position
			 */
			ArrayList<Integer> id_robots = new ArrayList<>();
			ArrayList<Noeud> localisation_robot = new ArrayList<>();

			/*
			 * Comme on a besoin du nombre total des robots on ne peut pas les insérer à la
			 * volée dans la topology donc on sauvegarde leur identifiant et leur futur
			 * position pour les créer par la suite
			 */
			while (cpt_robot > 0) {
				for (Noeud n : graphe.getNoeuds()) {
					if (Math.random() * 100 < 50 && cpt_robot > 0) {
						int identifiant = (int) (Math.random() * 100);
						while (id_robots.contains(identifiant) || identifiant == 0) {
							identifiant = (int) (Math.random() * 100);
						}
						id_robots.add(identifiant);
						localisation_robot.add(n);
						System.out.println("id " + identifiant + " Localisation " + n.getLocation());
						cpt_robot--;

					}

				}
			}

			// On peut maintenant les créer et les insérer dans la Topology

			for (int i = 0; i < id_robots.size(); i++) {
				Noeud position = localisation_robot.get(i);
				tp.addNode(position.getX(), position.getY(), new Robot(type_graphe, id_robots.get(i), position,
						nb_robot, nb_noeuds, timeout, can_finish, robot, tp));
				;
			}

			/*
			 * On écrit dans un fichier : - la valeur de la borne réapparition arête
			 * (utilisée seulement pour BRE) - le nombre de noeuds du graphe - le nombre de
			 * robots ainsi que leur id
			 */

			// suit le traitement des résultats
			// File file = new File("/users/Etu0/3520440/Resultats_" + type_graphe);
			File file = new File("/home/celia/Resultats_" + type_graphe);
			if (!file.exists()) {
				try {
					file.createNewFile();
				} catch (IOException ee) {
					// TODO Auto-generated catch block
					ee.printStackTrace();
				}
			}
			try {
				DataOutputStream out = new DataOutputStream(new FileOutputStream(file, true));
				out.writeBytes("Borne " + borne + "\n");
				out.writeBytes("Noeuds " + nb_noeud + "\n");
				out.writeBytes("Robots " + id_robots.size() + "\n");
				for (int i = 0; i < id_robots.size(); i++) {
					out.writeBytes("" + id_robots.get(i) + "\n");
				}
			} catch (FileNotFoundException ee) {
				ee.printStackTrace();
			} catch (IOException ee) {
				ee.printStackTrace();
			}

			// Permet la visualisation graphique de la simulation
			// new JViewer(tp);
			tp.start();

		}
	}

	public static void main(String[] args) {
		new Simulation_graphique();
	}
}