package traitements_resultats;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Analysis of the results documents. Warning, the files must respect a certain
 * form There is an example : Noeud 8\n Robots 4\n 13\n 14\n 34\n 22\n temps
 * 60\n G\n \n
 * 
 */

public class Analyse_fichier {

	/**
	 * This method returns true if the execution gathered robots in bounded time for
	 * ST
	 * 
	 * @param temps_execution Execution time of the simulation
	 * @param nb_noeud        Number of nodes
	 * @param nb_robots       Number of robots to gather
	 * @param id_min          Id min of robots
	 * @return returns true if the execution gathered robots in bounded time for ST
	 */
	public boolean G_ST_borne(int temps_execution, int nb_noeud, int nb_robots, int id_min) {
		if (temps_execution < 4 * nb_noeud * id_min + nb_noeud * (nb_robots - 2) + 4 * nb_noeud)
			return true;
		return false;
	}

	/**
	 * This method returns true if the execution gathered robots in bounded time for
	 * BRE
	 * 
	 * @param temps_execution Execution time of the simulation
	 * @param nb_noeud        Number of nodes
	 * @param nb_robots       Number of robots to gather
	 * @param id_min          Id min of robots
	 * @param borne           bound reappearance edge
	 * @return returns true if the execution gathered robots in bounded time for BRE
	 */
	public boolean G_BRE_borne(int temps_execution, int nb_noeud, int nb_robots, int id_min, int borne) {
		if (temps_execution < 4 * nb_noeud * id_min * borne + borne * nb_noeud * (nb_robots - 2) + 4 * nb_noeud * borne)
			return true;
		return false;
	}

	/**
	 * This methods returns true if the weak gathering was completed in bounded time
	 * for AC
	 * 
	 * @param temps_execution Execution time of the simulation
	 * @param nb_noeud        Number of nodes
	 * @param nb_robots       Number of robots to gather
	 * @param id_min          Id min of robots
	 * @return returns true if the weak gathering was completed in bounded time for
	 *         AC
	 *
	 */
	public boolean WG_AC_borne(int temps_execution, int nb_noeud, int nb_robots, int id_min) {
		if (temps_execution < 16 * id_min * nb_noeud * nb_noeud + 7 * nb_noeud * nb_noeud + 7 * nb_noeud
				+ (nb_robots - 3) * 3 * nb_noeud) {
			return true;
		}
		return false;
	}

	/**
	 * This method reads the results of our simulations. It determines what type of
	 * gathering was done (gathering or weak gathering, bounded or not) Attention
	 * the file must respect a precise format !
	 * 
	 * @param path path to the file to analyze
	 * @throws IOException file issue
	 */
	public void fichier(String path) throws IOException {
		File file = new File(path);
		if (!file.exists() || file.isDirectory()) {
			System.out.println("Ce n'est pas le bon fichier");
			return;
		}
		BufferedReader in = new BufferedReader(new FileReader(path));
		ArrayList<Integer> id_robots = new ArrayList<>();

		// Variables
		String read;
		int nb_robots;
		int temps_execution;
		int nb_noeud = 0;
		String type_rassemblement;
		int gathering_borne = 0;
		int gathering_non_borne = 0;
		int weak_gathering_borne = 0;
		int weak_gathering_non_borne = 0;

		int borne = 0; // used only for BRE
		int nb_simulations = 0;

		while ((read = in.readLine()) != null) {
			nb_simulations++;
			System.out.println(nb_simulations);

			// Reading of the file
			String[] borne_tab = read.split(" ");
			borne = Integer.parseInt(borne_tab[1].replace("\n", ""));
			read = in.readLine();
			String[] noeud = read.split(" ");
			nb_noeud = Integer.parseInt(noeud[1].replace("\n", ""));
			read = in.readLine();
			String[] robots = read.split(" ");
			nb_robots = Integer.parseInt(robots[1].replace("\n", ""));

			id_robots = new ArrayList<>();
			for (int i = 0; i < nb_robots; i++) {
				read = in.readLine();
				id_robots.add(Integer.parseInt(read.replace("\n", "")));
			}
			read = in.readLine();
			String[] pas_de_temps = read.split(" ");
			temps_execution = Integer.parseInt(pas_de_temps[1].replace("\n", ""));
			type_rassemblement = in.readLine().replace("\n", "");

			in.readLine();

			// Analyze depending on the type of class
			int id_min = (int) Double.POSITIVE_INFINITY;
			for (int i = 0; i < id_robots.size(); i++) {
				if (id_robots.get(i) < id_min) {
					id_min = id_robots.get(i);
				}
			}

			// Gathering
			if (type_rassemblement.equals("G")) {

				// If we are in ST, we check if it is a bounded gathering
				if (path.contains("ST")) {
					if (G_ST_borne(temps_execution, nb_noeud, nb_robots, id_min)) {
						gathering_borne++;
					} else {
						gathering_non_borne++;
					}
				} else {
					// If we are in BRE, we check if it is a bounded gathering
					if (path.contains("BRE")) {
						if (G_BRE_borne(borne, temps_execution, nb_noeud, nb_robots, id_min)) {
							gathering_borne++;
						} else {
							gathering_non_borne++;
						}
					}
					// If we are not in BRE or ST the gathering cannot be bounded
					else {
						gathering_non_borne++;
					}
				}

			} else {
				// Weak gathering

				// If we are in AC, we check if the weak gathering was completed in bounded time
				if (path.contains("AC")) {
					if (WG_AC_borne(temps_execution, nb_noeud, nb_robots, id_min)) {
						weak_gathering_borne++;
					} else {
						weak_gathering_non_borne++;
					}
					// Otherwise the gathering is inevitably unbounded
				} else {
					weak_gathering_non_borne++;
				}
			}

		}

		System.out.println("Nombre de simulations " + nb_simulations + "\nNombre de G bornés " + gathering_borne
				+ " moyenne " + (gathering_borne * 100.0) / nb_simulations + "\nNombre de G non bornés "
				+ gathering_non_borne + " moyenne " + (gathering_non_borne * 100.0) / nb_simulations
				+ "\nNombre de WG bornés " + weak_gathering_borne + " moyenne "
				+ (weak_gathering_borne * 100.0) / nb_simulations + "\nNombre de WG non bornés "
				+ weak_gathering_non_borne + " moyenne " + (weak_gathering_non_borne * 100.0) / nb_simulations);
	}

	public static void main(String[] args) throws IOException {
		Analyse_fichier analyse = new Analyse_fichier();
		analyse.fichier("/home/celia/Resultats_RE");
	}

}
