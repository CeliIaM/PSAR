package robots;



import classes_graphes.Graphe;
import io.jbotsim.core.Node;
import io.jbotsim.core.Topology;

/**
 * This class allows the management of the graph.
 * It's a robot, performing the same steps LOOK, COMPUTE, MOVE as a Robot.
 * It is transparent for the user and is therefore not part of robots to gather .
 * It only ensures the modification of the graph.
 * 
 *  @see Robot 
 * 
 */
public class Robot_gestionnaire extends Node {
	
	/** Considered graph */
	private Graphe graphe;
	
	/** La Topology dans laquelle on affiche le graphe
	 * @see Topology*/
	private Topology tp;
	
		public Robot_gestionnaire(Graphe graph,Topology tp) {
			this.graphe=graph;
			this.tp=tp;
		}
		
		public Graphe getGraphe() {
			return graphe;
		}
		/** Le look est vide mais est essentiel pour assurer les barrières de synchronisation */
	   @Override
	    public void onPreClock() {  // LOOK
		   
	    }
	   /** Le compute est vide mais est essentiel pour assurer les barrières de synchronisation */
	    @Override
	    public void onClock(){      // COMPUTE
	    	
	    }
	    /** Modification du graphe et affichage de celui-ci */
	    @Override
	    public void onPostClock(){  // MOVE
	    	graphe.afficher(tp);
	        graphe.modifier();

//			Attente pour que les déplacements soient visibles 
//	       try {
//				Thread.sleep(200);
//			} catch (InterruptedException e) {
//				e.printStackTrace();
//			}
	    }
}
