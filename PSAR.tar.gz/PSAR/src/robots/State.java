package robots;


/**
 * Reprensents the possible state of a Robot
 * @author Célia and Katia
 *
 */
public enum State {PotentialMin,AwareSearcher,DumbSearcher,Righter,WaitingWalker,
	MinWaitingWalker,HeadWalker,TailWalker,MinTailWalker,LeftWalker};
	
