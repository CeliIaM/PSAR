package robots;



public enum State {PotentialMin,AwareSearcher,DumbSearcher,Righter,WaitingWalker,
	MinWaitingWalker,HeadWalker,TailWalker,MinTailWalker,LeftWalker};
	
