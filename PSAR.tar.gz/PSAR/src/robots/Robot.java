package robots;

import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import classes_graphes.Graphe;
import classes_graphes.Noeud;
import classes_graphes.RE;
import io.jbotsim.core.Link;
import io.jbotsim.core.Node;
import io.jbotsim.core.Point;
import io.jbotsim.core.Topology;
import io.jbotsim.ui.JViewer;

public class Robot extends Node {

	/* Attributs */

	// ***************************************************************************************************************************************

	/* General informations about robots **/

	/**
	 * Graph type : ST, BRE, AC, RE or COT
	 */
	private String type_graphe;

	/**
	 * The position of this robots at a moment t
	 */
	private Noeud actuel;

	/**
	 * Number of node in the graph
	 */
	private int nb_noeud;

	/**
	 * Number of robots
	 */
	private int nb_robot;

	/**
	 * State of the robot
	 */
	private State state = State.Righter;

	/**
	 * Direction of the robot
	 */
	private Direction dir = Direction.Right;

	/**
	 * The position of the robot at the moment t-1
	 */
	private Point lastlocation;

	/**
	 * Id of the robot
	 */
	private int id;

	/**
	 * Number of right step
	 * 
	 */
	private int rightStep = 0;

	/**
	 * Number of walk step
	 * 
	 */
	private int walkStep = 0;

	/**
	 * Id min that the robot knows
	 * 
	 */
	private int idMin = -1;

	/**
	 * Id of the potential min that the robot knows
	 * 
	 */
	private int idPotentialMin = -1;

	/**
	 * Id of the HeadWalker that the robot knows
	 * 
	 */
	private int idHeadWalker = -1;

	/**
	 * Graph of the simulation
	 * 
	 */
	private Graphe g;

	/**
	 * Target point of the robot for the round t
	 * 
	 */
	private Point target;

	/**
	 * True if the left edge where present at the previous round
	 * 
	 */
	private boolean AR_gauche = false;

	/**
	 * True if the left edge is present
	 * 
	 */
	private boolean AR_gaucheT;

	/**
	 * True if the right edge is present
	 * 
	 */
	private boolean AR_droitT;

	/**
	 * Robot managing the graph
	 * 
	 */
	private Robot_gestionnaire gestionnaire;

	/**
	 * Phase that the robot will execute in the move section
	 * 
	 */
	private String action;

	/*
	 * Back-up of the different informations of robots which are on the same node
	 * that this robot
	 */

	/**
	 * Robots which are on the same node that this robot
	 * 
	 */
	private ArrayList<Robot> nodeMate = new ArrayList<>();

	/**
	 * Ids of robots which are on the same node that this robot
	 * 
	 */
	private ArrayList<Integer> nodeMateId = new ArrayList<>();

	/**
	 * Ids of the R−2 robots that initiate the Phase W
	 * 
	 */
	private ArrayList<Integer> walkerMate = new ArrayList<>();

	/**
	 * State of robots which are on the same node that this robot
	 * 
	 */
	private ArrayList<State> stateNodeMate = new ArrayList<>();

	/**
	 * Potential min of robots which are on the same node that this robot
	 * 
	 */
	private ArrayList<Integer> idPotentialNodeMate = new ArrayList<>();

	/**
	 * Id Min of robots which are on the same node that this robot
	 * 
	 */
	private ArrayList<Integer> idMinNodeMate = new ArrayList<>();

	/**
	 * Id of the HeadWalker of robots which are on the same node that this robot
	 * 
	 */
	private ArrayList<Integer> idheadWalderNodeMate = new ArrayList<>();

	/**
	 * List of the walker mate of robots which are on the same node that this robot
	 */
	private ArrayList<ArrayList<Integer>> walkermateNodeMate = new ArrayList<>();

	/**
	 * Number of walk step of robots which are on the same node that this robot
	 * 
	 */
	private ArrayList<Integer> walkStepNodeMate = new ArrayList<>();

	/**
	 * Position of robot use for the predicates of the algorithm
	 * 
	 */
	private int indice_r_prime;

	/*
	 * Information related to the stop of the execution
	 * 
	 */

	/**
	 * Time when after the weak gathering the simulation stops
	 * 
	 */
	private int timeout;

	/**
	 * True if the gathering is possible
	 * 
	 */
	private boolean can_finish;

	/**
	 * Time counter
	 * 
	 */
	private int pas_de_temps = 0;

	/**
	 * Weak gathering time counter
	 * 
	 */
	private int temps_wg = 0;

	/*
	 * JbotSim element
	 */

	/**
	 * Topology of the simulations
	 * 
	 */
	private Topology tp;

	/**
	 * Path for results file
	 * 
	 */

	/* Constructor */
	// ***********************************************************************************************************************

	/**
	 * 
	 * @param type_graphe Graph type : ST, BRE, AC, RE or COT
	 * @param id          Id of the robot
	 * @param n           Positon of the robot
	 * @param nb_robot    Number of robot
	 * @param nb_noeud    Number of nodes
	 * @param timeout     Time when after the weak gathering the simulation stops
	 * @param can_finish  True if the gathering is possible
	 * @param gest        Robot managing the graph
	 * @param top         Topology of the simulation
	 */
	public Robot(String type_graphe, int id, Noeud n, int nb_robot, int nb_noeud, int timeout, boolean can_finish,
			Robot_gestionnaire gest, Topology top) {
		this.type_graphe = type_graphe;
		this.id = id;
		this.nb_robot = nb_robot;
		this.nb_noeud = nb_noeud;
		this.actuel = n;

		this.timeout = timeout;
		this.can_finish = can_finish;
		gestionnaire = gest;
		this.setID(id);
		setIcon("images.png");
		setIconSize(16);
		System.out.println("ID robot est " + id);
		tp = top;
	

	}

	/* PREDICATES OF THE ALGORITHM */
	// ***********************************************************************************************************************************************

	public boolean minDiscovery() {
		int i;
		if (this.rightStep == (4 * this.id * nb_noeud)) {
			return true;
		} else {
			for (i = 0; i < nodeMate.size(); i++) {
				if (this.state.equals(State.PotentialMin)
						&& (nodeMate.get(i).getState().equals(State.Righter) && this.id < nodeMateId.get(i)))
					return true;

				if (nodeMate.get(i).getIDmin() == this.id)
					return true;

				if ((nodeMate.get(i).getState().equals(State.DumbSearcher)
						|| nodeMate.get(i).getState().equals(State.PotentialMin))
						&& this.id < nodeMate.get(i).getIDpotentialMin())
					return true;

			}
		}
		return false;
	}

	public boolean gathering() {
		return (nodeMate.size() == nb_robot - 1) ? true : false;
	}

	public boolean weakGathering() {
		int i;
		if (nodeMate.size() == nb_robot - 2) {
			if (this.state.equals(State.MinTailWalker) || this.state.equals(State.MinWaitingWalker))
				return true;
			for (i = 0; i < nodeMate.size(); i++) {
				if (nodeMate.get(i).getState().equals(State.MinTailWalker)
						|| nodeMate.get(i).getState().equals(State.MinWaitingWalker))
					return true;
			}
		}

		return false;
	}

	public boolean headWalkerWithoutWalkerMate() {
		return (this.state.equals(State.HeadWalker) && this.existsEdge(Direction.Left, -1) && !this.hasmoved()
				&& !compareListeId(nodeMateId, walkerMate)) ? true : false;
	}

	public boolean leftWalker() {
		return (this.state.equals(State.LeftWalker)) ? true : false;
	}

	public boolean headOrTailWalkerEndDiscovery() {
		return (this.headOrTailWalker() && nb_noeud == walkStep) ? true : false;

	}

	public boolean headOrTailWalker() {
		return (this.state.equals(State.HeadWalker) || this.state.equals(State.MinTailWalker)
				|| this.state.equals(State.TailWalker)) ? true : false;
	}

	public boolean allButTwoWaitingWalker() {
		int i;
		if (nodeMate.size() == nb_robot - 3) {
			if (!this.waitingWalker())
				return false;
			for (i = 0; i < nodeMate.size(); i++) {
				if (!nodeMate.get(i).waitingWalker())
					return false;
			}
			return true;
		}
		return false;
	}

	public boolean waitingWalker() {
		return (this.state.equals(State.WaitingWalker) || this.state.equals(State.MinWaitingWalker)) ? true : false;
	}

	public boolean potentialMinOrSearcherWithMinWaiting(Robot r) {
		if ((this.searcher() || this.state.equals(State.PotentialMin)) && r.getState().equals(State.MinWaitingWalker))
			return true;
		return false;
	}

	public boolean righterWithMinWaiting(Robot r) {
		return (this.state.equals(State.Righter) && r.getState().equals(State.MinWaitingWalker)) ? true : false;
	}

	public boolean notWalkerWithHeadWalker(Robot r) {
		return ((this.searcher() || this.potentialMinOrRighter()) && (r.getState().equals(State.HeadWalker))) ? true
				: false;
	}

	public boolean notWalkerWithTailWalker(Robot r) {
		return ((this.searcher() || this.potentialMinOrRighter()) && (r.getState().equals(State.MinTailWalker))) ? true
				: false;
	}

	public boolean potentialMinWithAwareSeacher(Robot r) {
		return (this.state.equals(State.PotentialMin) && r.getState().equals(State.AwareSearcher)) ? true : false;
	}

	public boolean allButOneRighter() {
		int i;
		if (nodeMate.size() == nb_robot - 2) {
			if (!this.state.equals(State.Righter))
				return false;
			for (i = 0; i < nodeMate.size(); i++) {
				if (!nodeMate.get(i).getState().equals(State.Righter))
					return false;
			}
			return true;
		}
		return false;
	}

	public boolean righterWithSearcher(Robot r) {
		return (this.state.equals(State.Righter) && r.searcher()) ? true : false;
	}

	public boolean potentialMinOrRighter() {
		return (this.state.equals(State.Righter) || this.state.equals(State.PotentialMin)) ? true : false;
	}

	public boolean dumbSearcherMinRevelation() {
		int i;
		if (this.state.equals(State.DumbSearcher)) {
			for (i = 0; i < nodeMate.size(); i++) {
				if (nodeMate.get(i).getState().equals(State.Righter) && this.idPotentialMin < nodeMateId.get(i))
					return true;
			}
		}
		return false;
	}

	public boolean dumbSearcherWithAwareSearcher(Robot r) {
		return (this.state.equals(State.DumbSearcher) && r.getState().equals(State.AwareSearcher)) ? true : false;
	}

	public boolean searcher() {
		return (this.state.equals(State.AwareSearcher) || this.state.equals(State.DumbSearcher)) ? true : false;
	}

	// Added functions
	// ************************************************************************************************************

	/**
	 * Compare the contents of two lists no matter the emplacements of integers
	 * 
	 * @param list first llist to compare
	 * @param list2  second list to compare
	 * @return true if the contents of list and list2 are equivalent
	 */
	public boolean compareListeId(ArrayList<Integer> list, ArrayList<Integer> list2) {
		if (list.size() != list2.size()) {
			return false;
		}
		boolean present = true;
		for (int i = 0; i < list.size(); i++) {
			for (int j = 0; j < list2.size(); j++) {
				if (list.get(i) == list2.get(j)) {
					present = false;
				}
			}
			if (present) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Returns true if an edge exists in the direction r and at the time t
	 * 
	 * @param r Direction to consider
	 * @param t Time to consider : 0 if it is now , -1 for the previous round
	 * @return Return true if there is an edge at the time t and on the direction r
	 */
	public boolean existsEdge(Direction r, int t) {
		if (t == -1) {
			if (r.equals(Direction.Left))
				return AR_gauche;

		} else if (t == 0) {
			if (r.equals(Direction.Left))
				return AR_gaucheT;
			else {
				return AR_droitT;
			}
		}
		return false;

	}

	/**
	 * 
	 * @return Return the state of a robot
	 */
	public State getState() {
		return this.state;
	}

	/**
	 * 
	 * @return Return a list of integers with the ids of robots who were on the same
	 *         node just before initiating the walk.
	 */
	public ArrayList<Integer> getWalkerMate() {
		return walkerMate;
	}

	/**
	 * 
	 * @return Return the id of the HeadWalker
	 */
	public int getIDHeadWalker() {
		return idHeadWalker;
	}

	/**
	 * @return Return the id of this robot
	 */
	public int getID() {
		return id;
	}

	/**
	 * 
	 * @return Return the idMin of this robot
	 */
	public int getIDmin() {
		return idMin;
	}

	/**
	 * 
	 * @return Return the id of the potential min for this robot
	 */
	public int getIDpotentialMin() {
		return idPotentialMin;
	}

	/**
	 * 
	 * @return Return true if the robot moved at the previous round
	 */
	boolean hasmoved() {
		return (lastlocation.equals(actuel.getLocation())) ? false : true;
	}

	/**
	 * 
	 * @return Return walkStep
	 */
	public int getWalkStep() {
		return walkStep;
	}

	// ACTION METHODS OF THE ALGORITHM
	// *************************************************************************************************************************

	void stopMoving() {
		dir = Direction.none;
	}

	void moveLeft() {
		dir = Direction.Left;
	}

	void becomeLeftWalker() {
		dir = Direction.none;
		state = State.LeftWalker;
	}

	void walk() {
		if ((id == idHeadWalker && !compareListeId(nodeMateId, walkerMate))
				|| (id != idHeadWalker && nodeMateId.contains(idHeadWalker))) {
			dir = Direction.none;

		} else {
			dir = Direction.Right;

		}
		if (dir == Direction.Right && existsEdge(Direction.Right, 0)) {
			walkStep = walkStep + 1;
		}
	}

	void initiateWalk() {
		idHeadWalker = id;
		for (int i = 0; i < nodeMateId.size(); i++) {
			if (idHeadWalker < nodeMateId.get(i)) {
				idHeadWalker = nodeMateId.get(i);
			}
		}
		for (int i = 0; i < nodeMateId.size(); i++) {
			walkerMate.add(nodeMateId.get(i));
		}
		if (id == idHeadWalker) {
			state = State.HeadWalker;
			return;
		}
		if (state == State.MinWaitingWalker) {
			state = State.MinTailWalker;
			return;
		}
		state = State.TailWalker;
	}

	void becomeWaitingWalker(int r_prime_id) {
		state = State.WaitingWalker;
		idPotentialMin = r_prime_id;
		idMin = r_prime_id;
		dir = Direction.none;

	}

	void becomeMinWaitingWalker() {
		state = State.MinWaitingWalker;
		idPotentialMin = id;
		idMin = id;
		dir = Direction.none;
	}

	void becomeAwareSearcher(State r_prime_state, int r_prime_idpotentialMin, int r_prime_min) {

		if (r_prime_state == State.DumbSearcher) {
			idPotentialMin = r_prime_idpotentialMin;
			idMin = r_prime_idpotentialMin;

		} else {
			idPotentialMin = r_prime_min;
			idMin = r_prime_min;
		}
		state = State.AwareSearcher;
		dir = Direction.Right;

	}

	void becomeTailWalker(int r_prime_idpotential, int r_prime_idMin, int r_idHeadWalker, int r_walkstep,
			ArrayList<Integer> walkermate) {
		state = State.TailWalker;
		idPotentialMin = r_prime_idpotential;
		idMin = r_prime_idMin;
		idHeadWalker = r_idHeadWalker;
		walkStep = r_walkstep;
		walkerMate = new ArrayList<>();
		for (int i = 0; i < walkermate.size(); i++) {
			walkerMate.add(walkermate.get(i));
		}

	}

	void moveRight() {
		dir = Direction.Right;
		if (existsEdge(dir, 0)) {
			rightStep = rightStep + 1;
		}
	}

	void initiateSearch() {
		idPotentialMin = id;
		for (int i = 0; i < nodeMateId.size(); i++) {
			if (idPotentialMin > nodeMateId.get(i)) {
				idPotentialMin = nodeMateId.get(i);
			}
		}
		if (idPotentialMin == id) {
			state = State.PotentialMin;
		} else {
			state = State.DumbSearcher;
		}
		if (state == State.PotentialMin && existsEdge(dir, 0)) {
			rightStep = rightStep + 1;
		}
	}

	void search() {
		boolean max = true;

		for (int i = 0; i < nodeMateId.size(); i++) {
			if (id < nodeMateId.get(i)) {
				max = false;
				break;
			}
		}
		if (nodeMate.size() >= 1 && max) {
			dir = Direction.Left;
			return;
		}
		if (nodeMate.size() >= 1 && !max) {
			dir = Direction.Right;
			return;
		}

	}

	/* LOOK COMPUTE MOVE */
	// ******************************************************************************************************************************

	/**
	 * LOOK : the robots updates his view
	 * 
	 */
	@Override
	public void onPreClock() {

		// New step, time incremented
		pas_de_temps++;
		System.out.println(pas_de_temps);

		// Resetting variables
		stateNodeMate = new ArrayList<>();
		idPotentialNodeMate = new ArrayList<>();
		idMinNodeMate = new ArrayList<>();
		idheadWalderNodeMate = new ArrayList<>();
		walkermateNodeMate = new ArrayList<>();
		walkStepNodeMate = new ArrayList<>();
		actuel = null;
		target = null;
		AR_droitT = false;
		AR_gaucheT = false;
		nodeMate = new ArrayList<>();
		nodeMateId = new ArrayList<>();

		// Get updated graph
		g = gestionnaire.getGraphe();
		ArrayList<Noeud> noeuds = g.getNoeuds();

		// Find the actual location of the robot
		for (Noeud n : noeuds) {
			if (this.getLocation().equals(n.getLocation())) {
				actuel = n;

			}
		}

		// Check if edges exist
		for (Link l : g.getLinks()) {
			List<Node> endpoints = l.endpoints();
			if (endpoints.contains(actuel)) {
				Noeud voisin = (Noeud) endpoints.get(0);
				if (voisin.equals(actuel)) {
					voisin = (Noeud) endpoints.get(1);
				}
				if (voisin.getLocation().equals(actuel.getSucc().getLocation())) {
					AR_droitT = true;
				} else {
					if (voisin.getLocation().equals(actuel.getPred().getLocation())) {
						AR_gaucheT = true;
					}
				}
			}

		}

		// Search robots on the same node and save their informations
		for (Node node : getSensedNodes()) {
			if (node instanceof Robot) {

				if (node.equals(this)) {
					continue;
				}
				Robot rob = (Robot) node;
				nodeMate.add(rob);
				nodeMateId.add(rob.getID());
				idheadWalderNodeMate.add(rob.getIDHeadWalker());
				idPotentialNodeMate.add(rob.idPotentialMin);
				idMinNodeMate.add(rob.idMin);
				walkermateNodeMate.add(rob.getWalkerMate());
				walkStepNodeMate.add(rob.walkStep);
				stateNodeMate.add(rob.getState());
			}
		}

	}

	/**
	 * COMPUTE : Robot determines which phase to execute thanks to the predicates
	 */
	@Override
	public void onClock() { // COMPUTE

		// Initialisation
		action = null;
		indice_r_prime = -1;

		// Check that only the first predicate which return true will execute the action
		// associated
		boolean phase_ok = false;

		// Termination
		if (gathering() && !phase_ok) {

			// Writing the result in a file
			phase_ok = true;
			File file = new File("Resultats_" + type_graphe);
			if (!file.exists()) {
				try {
					file.createNewFile();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}
			try {
				DataOutputStream out = new DataOutputStream(new FileOutputStream(file, true));
				out.writeBytes("temps " + pas_de_temps + "\n");
				out.writeBytes("G\n");
				out.writeBytes("\n");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}

			// End of the simulation
			System.exit(1);

		}

		// Weak gathering
		if (weakGathering() && !phase_ok) {
			action = "none";
			dir = Direction.none;
			phase_ok = true;
			if (temps_wg == 0) {
				temps_wg = pas_de_temps;
			}
			// If the gathering is impossible
			if (!can_finish) {

				// Decrementation of the timeout
				timeout--;

				// If the time out is negative the simulation must stop
				if (timeout <= 0) {

					// Writing the result on the file
					File file = new File("Resultats_" + type_graphe);
					if (!file.exists()) {
						try {
							file.createNewFile();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
					try {
						DataOutputStream out = new DataOutputStream(new FileOutputStream(file, true));
						out.writeBytes("temps " + temps_wg + "\n");
						out.writeBytes("WG\n\n");
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}

					// End of the simulation
					System.exit(1);

				}
			}
			System.out.println("Weak Gathering ok " + id);

		}

		// Phase T
		// **********************************************************************************************

		// T1
		if (leftWalker() && !phase_ok) {
			System.out.println("Phase T1 " + id + " ma direction  " + dir + " je suis un " + this.state);
			action = "T1";
			phase_ok = true;

		}

		// T2
		if (headWalkerWithoutWalkerMate() && !phase_ok) {
			System.out.println("Phase T2 " + id + " ma direction  " + dir + " je suis un " + this.state);
			action = "T2";
			phase_ok = true;
		}

		// T3
		if (headOrTailWalkerEndDiscovery() && !phase_ok) {
			action = "T3";
			System.out.println("Phase T3 " + id + " ma direction  " + dir + " je suis un " + this.state);
			phase_ok = true;
		}

		// Phase W
		// ***********************************************************************************************

		// W1
		if (headOrTailWalker() && !phase_ok) {
			action = "W1";
			System.out.println("Phase W1 " + id + " ma direction  " + dir + " je suis un " + this.state);
			phase_ok = true;
		}

		// Phase K
		// ***********************************************************************************************

		// K1
		if (allButTwoWaitingWalker() && !phase_ok) {
			action = "K1";
			System.out.println("Phase K1 " + id + " ma direction  " + dir + " je suis un " + this.state);
			phase_ok = true;
		}

		// K2
		if (waitingWalker() && !phase_ok) {
			System.out.println("Phase K2 " + id + " ma direction  " + dir + " je suis un " + this.state);
			action = "K2";
			phase_ok = true;
		}

		// K3
		for (int i = 0; i < nodeMate.size() && !phase_ok; i++) {
			if (potentialMinOrSearcherWithMinWaiting(nodeMate.get(i))) {
				System.out.println("Phase K3 " + id + " ma direction  " + dir + " je suis un " + this.state);
				action = "K3";
				indice_r_prime = i;
				phase_ok = true;

			}
		}

		// K4
		for (int i = 0; i < nodeMate.size() && !phase_ok; i++) {
			if (righterWithMinWaiting(nodeMate.get(i)) && existsEdge(Direction.Right, 0)) {
				action = "K4";
				indice_r_prime = i;
				System.out.println("Phase K4 " + id + " ma direction  " + dir + " je suis un " + this.state);
				phase_ok = true;

			}
		}

		// Phase M
		// ***********************************************************************************************

		// M1
		if (potentialMinOrRighter() && minDiscovery() && !phase_ok) {
			System.out.println("Phase M1 " + id + " ma direction  " + dir + " je suis un " + this.state);
			action = "M1";
			phase_ok = true;

		}

		// M2
		for (int i = 0; i < nodeMate.size() && !phase_ok; i++) {
			if (notWalkerWithHeadWalker(nodeMate.get(i)) && existsEdge(Direction.Right, 0)) {
				action = "M2";
				indice_r_prime = i;
				System.out.println("Phase M2 " + id + " ma direction  " + dir + " je suis un " + this.state);
				phase_ok = true;

			}
		}

		// M3
		for (int i = 0; i < nodeMate.size() && !phase_ok; i++) {
			if (notWalkerWithHeadWalker(nodeMate.get(i))) {
				action = "M3";
				indice_r_prime = i;
				System.out.println("Phase M3 " + id + " ma direction  " + dir + " je suis un " + this.state);
				phase_ok = true;

			}
		}

		// M4
		for (int i = 0; i < nodeMate.size() && !phase_ok; i++) {
			if (notWalkerWithTailWalker(nodeMate.get(i))) {
				action = "M4";
				indice_r_prime = i;
				System.out.println("Phase M4 " + id + " ma direction  " + dir + " je suis un " + this.state);
				phase_ok = true;

			}
		}

		// M5
		for (int i = 0; i < nodeMate.size() && !phase_ok; i++) {
			if (potentialMinWithAwareSeacher(nodeMate.get(i))) {
				action = "M5";
				indice_r_prime = i;
				this.AR_gauche = this.AR_droitT;
				System.out.println("Phase M5 " + id + " ma direction  " + dir + " je suis un " + this.state);
				phase_ok = true;

			}
		}

		// M6
		if (allButOneRighter() && !phase_ok) {
			System.out.println("Phase M6 " + id + " ma direction  " + dir + " je suis un " + this.state);
			action = "M6";
			phase_ok = true;

		}

		// M7
		for (int i = 0; i < nodeMate.size() && !phase_ok; i++) {
			if (righterWithSearcher(nodeMate.get(i))) {
				System.out.println("Phase M7 " + id + " ma direction  " + dir + " je suis un " + this.state);
				action = "M7";
				indice_r_prime = i;
				phase_ok = true;

			}
		}

		// M8
		if (potentialMinOrRighter() && !phase_ok) {
			System.out.println("Phase M8 " + id + " ma direction  " + dir + " je suis un " + this.state);
			action = "M8";
			phase_ok = true;

		}

		// M9
		if (dumbSearcherMinRevelation() && !phase_ok) {
			System.out.println("Phase M9 " + id + " ma direction  " + dir + " je suis un " + this.state);
			action = "M9";
			phase_ok = true;

		}

		// M10
		for (int i = 0; i < nodeMate.size() && !phase_ok; i++) {
			if (dumbSearcherWithAwareSearcher(nodeMate.get(i))) {
				System.out.println("Phase M10 " + id + " ma direction  " + dir + " je suis un " + this.state);
				action = "M10";
				indice_r_prime = i;
				System.out.println("dans m10 " + indice_r_prime);
				phase_ok = true;
			}
		}

		// M11
		if (searcher() && !phase_ok) {
			System.out.println("Phase M11 " + id + " ma direction  " + dir + " je suis un " + this.state);
			action = "M11";

			phase_ok = true;
		}

		// Saving the last location before moving
		lastlocation = this.getLocation();

	}

	/**
	 * MOVE : The robot executes the action determined in the COMPUTE
	 * 
	 */
	@Override
	public void onPostClock() { // MOVE

		// Depending on action, a method of action is executed
		switch (action) {
		case "T1":
			moveLeft();
			break;
		case "T2":
			becomeLeftWalker();
			break;
		case "T3":
			stopMoving();
			break;
		case "W1":
			walk();
			break;
		case "K1":
			initiateWalk();
			break;
		case "K2":
			stopMoving();
			break;
		case "K3":
			becomeWaitingWalker(nodeMateId.get(indice_r_prime));
			break;
		case "K4":
			becomeAwareSearcher(stateNodeMate.get(indice_r_prime), idPotentialNodeMate.get(indice_r_prime),
					idMinNodeMate.get(indice_r_prime));
			break;
		case "M1":
			becomeMinWaitingWalker();
			break;
		case "M2":
			becomeAwareSearcher(stateNodeMate.get(indice_r_prime), idPotentialNodeMate.get(indice_r_prime),
					idMinNodeMate.get(indice_r_prime));
			break;
		case "M3":
			becomeAwareSearcher(stateNodeMate.get(indice_r_prime), idPotentialNodeMate.get(indice_r_prime),
					idMinNodeMate.get(indice_r_prime));
			stopMoving();
			break;
		case "M4":
			becomeTailWalker(idPotentialNodeMate.get(indice_r_prime), idMinNodeMate.get(indice_r_prime),
					idheadWalderNodeMate.get(indice_r_prime), walkStepNodeMate.get(indice_r_prime),
					walkermateNodeMate.get(indice_r_prime));
			walk();
			break;
		case "M5":
			becomeAwareSearcher(stateNodeMate.get(indice_r_prime), idPotentialNodeMate.get(indice_r_prime),
					idMinNodeMate.get(indice_r_prime));
			search();
			break;

		case "M6":
			initiateSearch();
			break;
		case "M7":
			becomeAwareSearcher(stateNodeMate.get(indice_r_prime), idPotentialNodeMate.get(indice_r_prime),
					idMinNodeMate.get(indice_r_prime));
			search();
			break;
		case "M8":
			moveRight();
			break;
		case "M9":
			becomeAwareSearcher(this.state, this.idPotentialMin, this.idMin);
			search();
			break;
		case "M10":
			becomeAwareSearcher(stateNodeMate.get(indice_r_prime), idPotentialNodeMate.get(indice_r_prime),
					idMinNodeMate.get(indice_r_prime));
			search();
			break;
		case "M11":
			search();
			break;
		default:
			break;
		}

		// Initialize the target at the actual location od the robot
		target = this.getLocation();

		// Determine depending the direction the target
		for (Noeud node : g.getNoeuds()) {

			if (dir == Direction.Right && node.equals(actuel.getSucc()) && AR_droitT == true) {

				target = node.getLocation();

			} else {
				if (dir == Direction.Left && node.equals(actuel.getPred()) && AR_gaucheT == true) {

					target = node.getLocation();

				}
			}
		}

		// If the target didn't change nothing to do except the actualization of the
		// previous left edge
		if (target == this.getLocation()) {
			this.AR_gauche = this.AR_gaucheT;
			return;
		}

		// If we moved, the previous left edge will be the right edge
		this.AR_gauche = this.AR_droitT;

		// Change the location of the robot
		setLocation(target.getX(), target.getY());

		/*
		 * JbotSim can add links when nodes are close so we remove those links to not
		 * distort the visualization of the simulation
		 * 
		 */
		for (Link l : tp.getLinks()) {
			if (l.endpoints().contains(this)) {
				tp.removeLink(l);
			}
		}

//		Waiting to make displacements visible
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}