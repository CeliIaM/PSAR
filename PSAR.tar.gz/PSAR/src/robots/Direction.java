package robots;


/**
 * Reprensents the possible direction of a Robot
 * @author Célia and Katia
 *
 */
public enum Direction {Right,Left,none};