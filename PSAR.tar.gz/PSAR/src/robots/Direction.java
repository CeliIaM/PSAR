package robots;

public enum Direction {Right,Left,none};