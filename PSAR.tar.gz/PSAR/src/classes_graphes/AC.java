package classes_graphes;

import java.util.ArrayList;

import io.jbotsim.core.Link;
import io.jbotsim.core.Topology;
import io.jbotsim.ui.JViewer;

/**
 * This class generates a AC (always conncted) always conncted in time.
 */
public class AC implements Graphe {

	/**
	 * Probability of a missing edge
	 */
	private double proba;

	/**
	 * Number of nodes in the graph
	 */
	private int nb_noeud;

	/**
	 * Terminal time fixed at the beginning and increases throughout the execution
	 */
	private int temps_max;

	/**
	 * The unique missing edges
	 */
	private Link disparu = null;

	/**
	 * Time after which the missing edges will reappear
	 */
	private int temps_disparu;

	/**
	 * List node of the graph
	 */
	private ArrayList<Noeud> graph;

	/**
	 * Present edges in the graph
	 */
	private ArrayList<Link> liens;

	/**
	 * Probability of an eventual missing edge
	 */
	private double probabilite_missing_edge;

	/**
	 * Time when we try to pull the missing edge
	 */
	private int temps_tirage;

	/** Indicate if there is an eventual missing edge
	 * 
	 */
	private boolean missing_edge;

	/** List evey link possible
	 * 
	 */
	private ArrayList<Link> every_liens;

	/**
	 * This function allow to create an AC graph
	 * 
	 * @param noeud     Number of nodes
	 * @param proba_simple   Probability of a missing edge
	 * @param proba_missing_edge Probability of an eventual missing edge
	 * @param temps_max Terminal time
	 * @param temps_tirage_missing_edge Time when we try to pull the missing edge
	 */
	public AC(int noeud, double proba_simple, int temps_max, double proba_missing_edge, int temps_tirage_missing_edge) {
		missing_edge = false;
		this.proba = proba_simple;
		this.probabilite_missing_edge = proba_missing_edge;
		this.temps_max = temps_max;
		temps_tirage = temps_tirage_missing_edge;
		nb_noeud = noeud;
		graph = new ArrayList<Noeud>();
		liens = new ArrayList<Link>();
		every_liens = new ArrayList<Link>();

		for (int i = 0; i < nb_noeud; i++) {
			graph.add(new Noeud());
		}
		for (int i = 0; i < nb_noeud; i++) {
			graph.get(i).setSucc(graph.get((i + 1) % nb_noeud));
			graph.get(i).setPred(graph.get(Math.floorMod(i - 1, nb_noeud)));
		}
		for (int i = 0; i < nb_noeud; i++) {
			Link l = new Link(graph.get(i), graph.get((i + 1) % nb_noeud));
			liens.add(l);
			every_liens.add(l);
		}

	}

	/**
	 * Function that allows to modify the edges of the graph, it's handles the
	 * disappearance and the reappearance of the edges to respect the constraints of
	 * AC this function is called at each step to make the graph evolve.
	 */
	public void modifier() {

		temps_tirage--;

		// Time to pull the missing edge
		if (temps_tirage == 0) {
			if (Math.random() * 100 < probabilite_missing_edge) {
				int indice = (int) Math.random() * every_liens.size();

				// The link is in liens
				if (liens.contains(every_liens.get(indice))) {
					liens.remove(every_liens.get(indice));

				} else {
					// The link was already not present
					missing_edge = true;
					disparu = null;

				}
			}
		}
		// If a link disappeared
		if (disparu != null && missing_edge) {
			if (temps_disparu == 0) {
				liens.add(disparu);
				disparu = null;
			} else {
				temps_disparu--;
			}

		}

		if (Math.random() * 100 < proba && disparu == null) {
			int indice = (int) (Math.random() * liens.size());
			int temps = (int) (Math.random() * temps_max);
			disparu = liens.get(indice);
			temps_disparu = temps;
			liens.remove(indice);
			temps_max = temps_max + temps;
		}

	}

	/**
	 * Function that allows to display the graph
	 * 
	 * @param tp the topology in which we will display the graph
	 */
	public void afficher(Topology tp) {
		int taille_arête = 100;
		int largeure = (tp.getWidth() + nb_noeud * 5);
		for (int i = 0; i < nb_noeud; i++) {
			if (nb_noeud % 2 == 0) {
				/* the node which should be at the top of the frame */
				if (i == (nb_noeud / 2)) {
					tp.addNode(tp.getWidth(), largeure - i * taille_arête, graph.get(i));

				}
			}

			if (i == 0) {
				/* the node which should be at the bottom of the frame */
				tp.addNode(tp.getWidth(), largeure - i * taille_arête, graph.get(i));

			} else {
				if (i < (nb_noeud / 2)) {
					/* the node which should be at the left of the frame */
					tp.addNode(tp.getHeight(), largeure - i * taille_arête, graph.get(i));
				} else {
					/* the node which should be at the right of the frame */
					tp.addNode(tp.getHeight() + 2 * (tp.getWidth() - tp.getHeight()),
							largeure - ((nb_noeud - i) * taille_arête), graph.get(i));
				}

			}
		}
		/* delete all the links contained the topology */
		tp.clearLinks();
		for (int i = 0; i < liens.size(); i++) {
			/* add the present links to the topology */
			tp.addLink(liens.get(i));
		}
	}

	/**
	 * This function allow to get the list of nodes contained in the graph
	 * 
	 * @return return a list of nodes
	 */
	public ArrayList<Noeud> getNoeuds() {
		return graph;
	}

	/**
	 * This function allow to get the list of present edges contained in the graph
	 * 
	 * @return return a list of edges
	 */
	public ArrayList<Link> getLinks() {
		return liens;
	}

}