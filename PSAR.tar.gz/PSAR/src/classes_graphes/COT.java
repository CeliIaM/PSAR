package classes_graphes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.jbotsim.core.Link;
import io.jbotsim.core.Topology;

/**
 * This class generates a COT (connected over time) graph, connected in time an
 * edge can appear and disappear aperiodically
 */
public class COT implements Graphe {

	/**
	 * Probability of a missing edge
	 */
	private double proba_disparition_simple;

	/**
	 * Probability of an eventual missing edge
	 */
	private double proba_missing_edge;

	/**
	 * Number of nodes in the graph
	 */
	private int nb_noeud;

	/**
	 * the missing edges associate to the time after which it will reappear
	 */
	private Map<Link, Integer> disparu;

	/**
	 * List nodes of the graph
	 */
	private ArrayList<Noeud> graph;

	/**
	 * List of the present edges of the graph
	 */
	private ArrayList<Link> liens;

	/**
	 * List of all the edges of the graph
	 */
	private ArrayList<Link> every_liens;

	/**
	 * Time when we try to pull the missing edge
	 */
	private int temps_tirage_missing_edge;

	/**
	 * Terminal time fixed at the begining and increases throughout the execution
	 */
	private int temps_max;

	/**
	 * This function allow to create a COT graph
	 * 
	 * @param noeud                     Number of nodes
	 * @param proba_disparition_simple  Probability of a missing edge
	 * @param proba_missing_edge        Probability of an eventual missing edge
	 * @param temps_tirage_missing_edge Time when we try to pull the missing edge
	 * @param temps_max                 Terminal time fixed at the beginning and
	 *                                  increases throughout the execution
	 * 
	 */
	public COT(int noeud, double proba_disparition_simple, double proba_missing_edge, int temps_tirage_missing_edge,
			int temps_max) {
		this.proba_disparition_simple = proba_disparition_simple;
		this.proba_missing_edge = proba_missing_edge;
		this.temps_tirage_missing_edge = temps_tirage_missing_edge;
		this.temps_max = temps_max;
		nb_noeud = noeud;
		disparu = new HashMap<>();
		graph = new ArrayList<Noeud>();
		liens = new ArrayList<Link>();
		every_liens = new ArrayList<Link>();
		temps_tirage_missing_edge = 0;
		for (int i = 0; i < nb_noeud; i++) {
			graph.add(new Noeud());
		}
		for (int i = 0; i < nb_noeud; i++) {
			graph.get(i).setSucc(graph.get((i + 1) % nb_noeud));
			graph.get(i).setPred(graph.get(Math.floorMod(i - 1, nb_noeud)));
		}
		for (int i = 0; i < nb_noeud; i++) {
			Link l = new Link(graph.get(i), graph.get((i + 1) % nb_noeud));
			liens.add(l);
			every_liens.add(l);

		}

	}

	// Methods

	/**
	 * Function that allows to modify the edges of the graph, it's handles the
	 * disaprition and the reappearance of the edges as to respect the constraints
	 * of COT this function is called at each step to make the graph evolve.
	 */
	@Override
	public void modifier() {

		temps_tirage_missing_edge--;

		// Time to pull the missing edge
		if (temps_tirage_missing_edge == 0) {
			if (Math.random() * 100 < proba_missing_edge) {
				int indice = (int) Math.random() * every_liens.size();

				// The link is in liens
				if (liens.contains(every_liens.get(indice))) {
					liens.remove(every_liens.get(indice));

				} else {
					// The link was already not present
					disparu.remove(every_liens.get(indice));

				}
			}
		}

		ArrayList<Link> supp = new ArrayList<Link>();
		List<Link> dis = new ArrayList<Link>(disparu.keySet());

		for (int i = 0; i < liens.size(); i++) {
			if (Math.random() * 100 <= proba_disparition_simple) {
				supp.add(liens.get(i));
			}
		}

		for (int i = 0; i < supp.size(); i++) {
			int temps = (int) (Math.random() * temps_max);

			/* Increase the terminal time */
			temps_max = temps_max + temps;
			disparu.put(supp.get(i), (int) (Math.random() * temps));

			/* remove the link from the graph */
			liens.remove(supp.get(i));

		}

		for (int i = 0; i < dis.size(); i++) {
			Link k = dis.get(i);
			int val = disparu.get(k);
			disparu.replace(k, val - 1);
			k = dis.get(i);
			val = disparu.get(k);
			/* the delay of disappearance comes to term */
			if (disparu.get(dis.get(i)) <= 0) {
				liens.add(k);
				disparu.remove(k);
			}
		}

	}

	/**
	 * Function that allows to display the graph
	 * 
	 * @param tp the topology in which we will display the graph
	 */
	public void afficher(Topology tp) {

		int taille_arête = 100;
		int largeure = (tp.getWidth() + nb_noeud * 5);
		for (int i = 0; i < nb_noeud; i++) {
			if (nb_noeud % 2 == 0) {
				/* the node which should be at the top of the frame */
				if (i == (nb_noeud / 2)) {
					tp.addNode(tp.getWidth(), largeure - i * taille_arête, graph.get(i));

				}
			}

			if (i == 0) {
				/* the node which should be at the bottom of the frame */
				tp.addNode(tp.getWidth(), largeure - i * taille_arête, graph.get(i));

			} else {
				if (i < (nb_noeud / 2)) {
					/* the node which should be at the left of the frame */
					tp.addNode(tp.getHeight(), largeure - i * taille_arête, graph.get(i));
				} else {
					/* the node which should be at the right of the frame */
					tp.addNode(tp.getHeight() + 2 * (tp.getWidth() - tp.getHeight()),
							largeure - ((nb_noeud - i) * taille_arête), graph.get(i));
				}

			}
		}
		/* delete all the links contained the topology */
		tp.clearLinks();
		for (int i = 0; i < liens.size(); i++) {
			/* add the present links to the topology */
			tp.addLink(liens.get(i));
		}
	}

	/**
	 * get the list of nodes contained in the graph
	 * 
	 * @return return a list of nodes
	 */
	public ArrayList<Noeud> getNoeuds() {
		return graph;
	}

	/**
	 * get the list of present edges contained in the graph
	 * 
	 * @return return a list of edges
	 */
	public ArrayList<Link> getLinks() {
		return liens;
	}

}