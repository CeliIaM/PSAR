package classes_graphes;

import java.util.ArrayList;

import io.jbotsim.core.Link;
import io.jbotsim.core.Topology;

public class ST implements Graphe {
	private int nb_noeud;
	private ArrayList<Noeud> graph;
	private ArrayList<Link> liens;

	public ST(int noeud) {
		nb_noeud = noeud;
		graph = new ArrayList<Noeud>();
		liens = new ArrayList<Link>();
		for (int i = 0; i < nb_noeud; i++) {
			graph.add(new Noeud());
		}
		for (int i = 0; i < nb_noeud; i++) {
			graph.get(i).setSucc(graph.get((i + 1) % nb_noeud));
			graph.get(i).setPred(graph.get(Math.floorMod(i - 1, nb_noeud)));
		}
		for (int i = 0; i < nb_noeud; i++) {
			liens.add(new Link(graph.get(i), graph.get((i + 1) % nb_noeud)));

		}
	}

	public void modifier() {

	}

	public void afficher(Topology tp) {

		int taille_arête = 100;
		int largeure = (tp.getWidth() + nb_noeud * 5);
		for (int i = 0; i < nb_noeud; i++) {
			if (i == nb_noeud - 1 || i == 0) {
				tp.addNode(tp.getWidth(), largeure - i * taille_arête, graph.get(i));

			} else {

				tp.addNode(tp.getHeight(), largeure - i * taille_arête, graph.get(i));
				tp.addNode(tp.getHeight() + 2 * (tp.getWidth() - tp.getHeight()), largeure - i * taille_arête,
						graph.get(graph.size() - i));
				nb_noeud--;
			}
		}
		tp.clearLinks();
		for (int i = 0; i < liens.size(); i++) {
			tp.addLink(liens.get(i));
		}
	}

	public ArrayList<Noeud> getNoeuds() {
		return graph;
	}

	public ArrayList<Link> getLinks() {
		return liens;
	}

	public void setGraph(ArrayList<Noeud> graph) {
		this.graph = graph;
	}

	public void setLiens(ArrayList<Link> liens) {
		this.liens = liens;
	}

}
