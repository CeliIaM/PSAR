package classes_graphes;

import io.jbotsim.core.Node;

/** Noeud du graphe */
public class Noeud extends Node{

	/** Prédécesseur */
	private Node pred;
	
	/** Successeur */
	private Node succ;
	
	public Noeud() {
		super();
		pred=null;
		succ=null;
	}

	/** 
	 * Accesseur sur le prédecesseur du noeud
	 * @return Retourne le prédecesseur de ce Noeud
	 */
	public Node getPred() {
		return pred;
	}

	
	public void setPred(Node pred) {
		this.pred = pred;
	}

	/** 
	 * Accesseur sur le successeur du noeud
	 * @return Retourne le successeur de ce Noeud
	 */
	public Node getSucc() {
		return succ;
	}

	public void setSucc(Node succ) {
		this.succ = succ;
	}
	
	
}
