package classes_graphes;

import jbotsim.Topology;

public interface Graphe {

	public void modifier();
	public void afficher(Topology tp);
}
