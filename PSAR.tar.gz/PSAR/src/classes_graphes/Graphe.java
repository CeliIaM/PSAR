package classes_graphes;

import java.util.ArrayList;

import io.jbotsim.core.Link;
import io.jbotsim.core.Topology;

/**
 * Cette interface définit les méthodes essentielles d'un graphe 
 * Toutes les classes de graphes doivent l'implémenter
 */
public interface Graphe {

	public void modifier();
	public void afficher(Topology tp);
	public ArrayList<Noeud> getNoeuds();
	public ArrayList<Link> getLinks();
}
