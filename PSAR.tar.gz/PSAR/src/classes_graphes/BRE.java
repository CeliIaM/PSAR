package classes_graphes;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import io.jbotsim.core.Link;
import io.jbotsim.core.Topology;
import io.jbotsim.ui.JViewer;
import robots.Robot;

/**
 * This class generates a BRE (bounded recurrent edge) graph, an edge that
 * appears once, reappears recursively, and bounds in time.
 */
public class BRE implements Graphe {
	/**
	 * Probability of a missing edge
	 */
	private double proba;
	
	/**
	 * Number of nodes in the graph
	 */
	private int nb_noeud;
	
	/**
	 * Bound at the end of which a missing edge reappears inevitably
	 */
	private int temps;
	
	/**
	 * The missing edges associated to the time after which it will reappear
	 */
	private Map<Link, Integer> disparu;
	
	/**
	 * List of nodes contained in the graph
	 */
	private ArrayList<Noeud> graph;
	/**
	 * List of links contained in the graph
	 */
	private ArrayList<Link> liens;

	/**
	 * This function allows to create a BRE graph
	 * 
	 * @param noeud Number of nodes
	 * @param proba Probability of a missing edge
	 * @param temps Bound at the end of which a missing edge reappears inevitably
	 */
	public BRE(int noeud, double proba, int temps) {
		this.proba = proba;
		this.temps = temps;
		nb_noeud = noeud;
		disparu = new HashMap<>();
		graph = new ArrayList<Noeud>();
		liens = new ArrayList<Link>();
		for (int i = 0; i < nb_noeud; i++) {
			graph.add(new Noeud());
		}
		for (int i = 0; i < nb_noeud; i++) {
			graph.get(i).setSucc(graph.get((i + 1) % nb_noeud));
			graph.get(i).setPred(graph.get(Math.floorMod(i - 1, nb_noeud)));
		}
		for (int i = 0; i < nb_noeud; i++) {
			liens.add(new Link(graph.get(i), graph.get((i + 1) % nb_noeud)));

		}

	}

	public void setGraph(ArrayList<Noeud> graph) {
		this.graph = graph;
	}

	/**
	 * Function that allows to modify the edges of the graph, it's handles the
	 * disappearance and *the reappearance of the edges as to respect the constraints
	 * of BRE this function is called at each step to make the graph evolve.
	 */
	public void modifier() {
		ArrayList<Link> supp = new ArrayList<Link>();
		List<Link> dis = new ArrayList<Link>(disparu.keySet());

		for (int i = 0; i < liens.size(); i++) {
			double n = Math.random() * 100;
			if (n <= proba) {
				/* probability of a missing edge */
				supp.add(liens.get(i));
			}
		}
		for (int i = 0; i < supp.size(); i++) {
			disparu.put(supp.get(i), (int) (Math.random() * temps));
			/* remove the link from the graph */
			liens.remove(supp.get(i));

		}

		for (int i = 0; i < dis.size(); i++) {
			Link k = dis.get(i);
			int val = disparu.get(k);
			disparu.replace(k, val - 1);
			k = dis.get(i);
			val = disparu.get(k);
			/* the delay of disappearance comes to term */
			if (disparu.get(dis.get(i)) <= 0) {
				liens.add(k);
				disparu.remove(k);
			}
		}

	}

	/**
	 * Function that allows to display the graph
	 * 
	 * @param tp the topology in which we will display the graph
	 */
	public void afficher(Topology tp) {
		int taille_arête = 100;
		int largeure = (tp.getWidth() + nb_noeud * 5);
		for (int i = 0; i < nb_noeud; i++) {
			if (nb_noeud % 2 == 0) {
				/* the node which should be at the top of the frame */
				if (i == (nb_noeud / 2)) {
					tp.addNode(tp.getWidth(), largeure - i * taille_arête, graph.get(i));

				}
			}

			if (i == 0) {
				/* the node which should be at the bottom of the frame */
				tp.addNode(tp.getWidth(), largeure - i * taille_arête, graph.get(i));

			} else {
				if (i < (nb_noeud / 2)) {
					/* the node which should be at the left of the frame */
					tp.addNode(tp.getHeight(), largeure - i * taille_arête, graph.get(i));
				} else {
					/* the node which should be at the right of the frame */
					tp.addNode(tp.getHeight() + 2 * (tp.getWidth() - tp.getHeight()),
							largeure - ((nb_noeud - i) * taille_arête), graph.get(i));
				}

			}
		}
		/* delete all the links contained the topology */
		tp.clearLinks();
		for (int i = 0; i < liens.size(); i++) {
			/* add the present links to the topology */
			tp.addLink(liens.get(i));
		}
	}

	/**
	 * get the list of nodes contained in the graph
	 * 
	 * @return return a list of nodes
	 */
	public ArrayList<Noeud> getNoeuds() {
		return graph;
	}

	/**
	 * get the list of present edges contained in the graph
	 * 
	 * @return return a list of edges
	 */
	public ArrayList<Link> getLinks() {
		return liens;
	}

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		BRE st = new BRE(10, 100, 1);
		Topology tp = new Topology();
		st.afficher(tp);
		new JViewer(tp);
		tp.start();

	}

}